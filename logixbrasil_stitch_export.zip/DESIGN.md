# 🎨 LOGIX BRASIL - Especificação de Design para Stitch Beta (Google Labs)

Documento de arquitetura visual, design system, tokens e mapeamento de telas para importação e prototipagem no **Stitch Beta** (`stitch.withgoogle.com`).

---

## 📌 Visão Geral do Produto

- **Nome do Projeto**: LOGIX BRASIL
- **Categoria**: Logística, Transporte Rodoviário & Frete Aéreo Nacional
- **Mercado**: Brasil (27 UFs, capitais e interior)
- **Moeda**: Real Brasileiro (BRL - R$)
- **Público-Alvo**: Clientes B2B/B2C que necessitam enviar encomendas e cargas, e Administradores/Operadores logísticos.
- **Framework UI**: HTML5 + Tailwind CSS + Lucide Icons

---

## 🎨 Design Tokens & Sistema Visual

### Paleta de Cores (Tailwind)
- **Primary (Logística / Aéreo)**: `sky-600` (`#0284c7`), `sky-700` (`#0369a1`), `sky-50` (`#f0f9ff`)
- **Secondary (Corporativo / Rodoviário)**: `slate-900` (`#0f172a`), `slate-800` (`#1e293b`), `slate-100` (`#f1f5f9`)
- **Success / Aceito (Brasil / Eficiência)**: `emerald-600` (`#059669`), `emerald-50` (`#ecfdf5`)
- **Warning / Sujeito a Análise**: `amber-500` (`#f59e0b`), `amber-50` (`#fffbeb`)
- **Action Reanálise**: `orange-600` (`#ea580c`), `orange-50` (`#fff7ed`)
- **Danger / Recusa**: `rose-600` (`#e11d48`), `rose-50` (`#fff1f2`)

### Tipografia & Ícones
- **Fonte Principal**: `Inter`, sans-serif (`font-sans`)
- **Hierarquia**:
  - H1 Hero: `text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight`
  - H2 Seções: `text-3xl sm:text-4xl font-black tracking-tight`
  - H3 Cards: `text-xl font-bold`
  - Body: `text-xs / text-sm text-slate-600 leading-relaxed`
- **Ícones**: Lucide Icons (`plane-takeoff`, `truck`, `package`, `boxes`, `ruler`, `scale`, `clock`, `check-circle-2`, `refresh-cw`, `x-circle`, `shield-check`).

---

## 📱 Mapeamento de Telas (Screens) para o Stitch Beta

| Tela # | Nome da Tela | Descrição |
|---|---|---|
| **01** | `01_landing_page.html` | Vitrine comercial com Hero rodoviário e aéreo, simulador rápido de cubagem, catálogo de serviços e cobertura Brasil. |
| **02** | `02_quote_modal.html` | Modal interativo de cotação com modalidade (Aéreo/Rodo), volumes, dimensões (C x L x A cm), peso real kg, origem/destino no Brasil. |
| **03** | `03_sujeita_analise_modal.html` | Notificação modal oficial: *''Cotización de envio sujeta a analisis''* (*Cotação de envio sujeita a análise*) com código único de rastreio `COT-XXXX`. |
| **04** | `04_client_dashboard.html` | Painel do cliente com cotações ativas, proposta em BRL (R$) enviada e os 3 botões de ação: **Aceitar Proposta**, **Recusar** e **Solicitar Outra Análise**. |
| **05** | `05_admin_dashboard.html` | Painel de controle do gestor logístico com ficha técnica (peso real vs cubado), formulário para formular proposta em R$ e KPIs gerenciais. |
| **06** | `06_receipt_history.html` | Comprovante oficial impresso/digital de transporte e tabela de histórico de serviços concluídos em todo o país. |

---

## ⚡ Fluxo de Interação

```
[Visitante / Cliente] 
       ↓ 
Preenche Carga (Modal, Peso, Medidas, Origem/Destino)
       ↓
Submete Solicitação ➔ Exibe Modal Oficial: "Cotação de envio sujeita a análise"
       ↓
[Portal de Administração] 
       ↓
Analisa Peso Real vs Cubado ➔ Formula Preço em R$ + Prazo ➔ Envia Proposta
       ↓
[Painel do Cliente Notificado]
       ↓
Visualiza Proposta em R$ ➔ 3 Opções:
  ├─ [1] Aceitar Proposta ➔ Confirma Coleta / Serviço Ativo
  ├─ [2] Recusar ➔ Arquiva com Justificativa
  └─ [3] Solicitar Outra Análise ➔ Envia Contraproposta ao Administrador
```
