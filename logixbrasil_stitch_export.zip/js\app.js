/**
 * LOGIX BRASIL - Aplicación Web Principal
 * Controlador de interface, cotações com análise técnica (Aéreo e Rodoviário) em BRL (R$)
 * Autenticação estrita do Administrador: top10cargas@hotmail.com / Caxias844$
 * Upload de imagem da caixa e rastreamento contínuo de entregas em tempo real
 */

class App {
  constructor() {
    this.currentView = 'landing';
    this.currentClientTab = 'proposals';
    this.currentAdminTab = 'pending';
    this.currentQuoteForAction = null;
    this.currentUploadedImage = null;
    this.init();
  }

  init() {
    window.logixStore.subscribe(() => {
      this.render();
    });

    document.addEventListener('DOMContentLoaded', () => {
      this.setupEventListeners();
      this.render();
      lucide.createIcons();
    });

    if (window.logixStore.currentUser) {
      if (window.logixStore.currentUser.role === 'admin') {
        this.currentView = 'admin_dashboard';
      } else if (window.logixStore.currentUser.role === 'client') {
        this.currentView = 'client_dashboard';
      }
    }
  }

  setupEventListeners() {
    // Alternância de Perfil
    document.getElementById('btn-role-visitor')?.addEventListener('click', () => {
      window.logixStore.switchRole('guest');
      this.navigateTo('landing');
      this.showToast('Modo Visitante ativado (Landing pública)', 'info');
    });

    document.getElementById('btn-role-client')?.addEventListener('click', () => {
      window.logixStore.switchRole('client');
      this.navigateTo('client_dashboard');
      this.showToast('Modo Cliente ativado (Lucas Silveira)', 'success');
    });

    document.getElementById('btn-reset-demo')?.addEventListener('click', () => {
      if (confirm('Deseja restaurar todos os dados e cotações de demonstração?')) {
        window.logixStore.resetToDemo();
        this.navigateTo('client_dashboard');
        this.showToast('Dados de teste restaurados com sucesso!', 'info');
      }
    });

    // Dropdown Notificações
    const notifBtn = document.getElementById('btn-notifications-toggle');
    const notifDropdown = document.getElementById('notifications-dropdown');
    notifBtn?.addEventListener('click', (e) => {
      e.stopPropagation();
      notifDropdown.classList.toggle('hidden');
    });

    document.addEventListener('click', (e) => {
      if (!notifDropdown?.contains(e.target) && e.target !== notifBtn) {
        notifDropdown?.classList.add('hidden');
      }
    });

    document.getElementById('btn-mark-all-read')?.addEventListener('click', () => {
      window.logixStore.markAllNotificationsRead(window.logixStore.currentUser);
      this.showToast('Notificações marcadas como lidas', 'info');
    });
  }

  // --- CONTROLE DE ACESSO ADMINISTRATIVO RESTRITO ---
  requestAdminAccess() {
    const user = window.logixStore.currentUser;
    // Se já estiver logado como o admin autorizado, abre o painel direto
    if (user && user.role === 'admin' && user.email.toLowerCase() === 'top10cargas@hotmail.com') {
      this.navigateTo('admin_dashboard');
      return;
    }

    // Caso contrário, exige autenticação obrigatória
    document.getElementById('admin-auth-email').value = '';
    document.getElementById('admin-auth-password').value = '';
    document.getElementById('admin-auth-error-message').classList.add('hidden');
    document.getElementById('modal-admin-auth').classList.remove('hidden');
    lucide.createIcons();
  }

  closeAdminAuthModal() {
    document.getElementById('modal-admin-auth').classList.add('hidden');
  }

  handleAdminLoginSubmit(e) {
    e.preventDefault();
    const email = document.getElementById('admin-auth-email').value.trim();
    const pass = document.getElementById('admin-auth-password').value;

    try {
      const admin = window.logixStore.login(email, pass);
      if (admin.role !== 'admin') {
        throw new Error('Esta conta não possui permissões administrativas.');
      }
      this.closeAdminAuthModal();
      this.navigateTo('admin_dashboard');
      this.showToast(`Acesso autorizado! Bem-vindo à gestão Top 10 Cargas.`, 'success');
    } catch (err) {
      document.getElementById('admin-auth-error-text').textContent = err.message || 'Credenciais inválidas. Acesso exclusivo para top10cargas@hotmail.com.';
      document.getElementById('admin-auth-error-message').classList.remove('hidden');
    }
  }

  // --- NAVEGAÇÃO ENTRE TELAS ---
  navigateTo(viewName) {
    this.currentView = viewName;

    document.getElementById('view-landing').classList.add('hidden');
    document.getElementById('view-client-dashboard').classList.add('hidden');
    document.getElementById('view-admin-dashboard').classList.add('hidden');

    if (viewName === 'landing') {
      document.getElementById('view-landing').classList.remove('hidden');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (viewName === 'client_dashboard') {
      if (!window.logixStore.currentUser) {
        window.logixStore.switchRole('client');
      }
      document.getElementById('view-client-dashboard').classList.remove('hidden');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (viewName === 'admin_dashboard') {
      // Bloqueio de segurança
      const user = window.logixStore.currentUser;
      if (!user || user.role !== 'admin' || user.email.toLowerCase() !== 'top10cargas@hotmail.com') {
        this.requestAdminAccess();
        return;
      }
      document.getElementById('view-admin-dashboard').classList.remove('hidden');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    this.render();
  }

  // --- RENDERIZAÇÃO GERAL ---
  render() {
    this.renderNavbar();
    this.renderNotifications();

    if (this.currentView === 'client_dashboard') {
      this.renderClientDashboard();
    } else if (this.currentView === 'admin_dashboard') {
      this.renderAdminDashboard();
    }

    lucide.createIcons();
  }

  renderNavbar() {
    const user = window.logixStore.currentUser;
    const badge = document.getElementById('current-role-badge');
    const guestNav = document.getElementById('nav-auth-guest');
    const clientNav = document.getElementById('nav-auth-client');
    const adminNav = document.getElementById('nav-auth-admin');
    const clientNameNav = document.getElementById('nav-client-name');

    if (!user) {
      badge.textContent = 'Visitante Público';
      badge.className = 'bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700';
      guestNav.classList.remove('hidden');
      clientNav.classList.add('hidden');
      adminNav.classList.add('hidden');
    } else if (user.role === 'admin') {
      badge.textContent = `Administrador (${user.name})`;
      badge.className = 'bg-amber-950 text-amber-300 px-2 py-0.5 rounded border border-amber-800';
      guestNav.classList.add('hidden');
      clientNav.classList.add('hidden');
      adminNav.classList.remove('hidden');

      const pendingQuotes = window.logixStore.quotes.filter(q => q.status === 'PENDIENTE_ANALISIS' || q.status === 'REANALISIS_SOLICITADO');
      const navPendingBadge = document.getElementById('nav-admin-pending-badge');
      if (pendingQuotes.length > 0) {
        navPendingBadge.textContent = pendingQuotes.length;
        navPendingBadge.classList.remove('hidden');
      } else {
        navPendingBadge.classList.add('hidden');
      }
    } else {
      badge.textContent = `Cliente (${user.name})`;
      badge.className = 'bg-sky-950 text-sky-300 px-2 py-0.5 rounded border border-sky-800';
      guestNav.classList.add('hidden');
      clientNav.classList.remove('hidden');
      adminNav.classList.add('hidden');
      if (clientNameNav) clientNameNav.textContent = user.name;
    }
  }

  renderNotifications() {
    const user = window.logixStore.currentUser;
    const notifs = window.logixStore.getNotificationsForUser(user);
    const badgeCount = document.getElementById('notif-badge-count');
    const listContainer = document.getElementById('notifications-list');

    const unreadCount = notifs.filter(n => !n.read).length;

    if (unreadCount > 0) {
      badgeCount.textContent = unreadCount;
      badgeCount.classList.remove('hidden');
    } else {
      badgeCount.classList.add('hidden');
    }

    if (!listContainer) return;

    if (notifs.length === 0) {
      listContainer.innerHTML = `
        <div class="p-6 text-center text-slate-400">
          <i data-lucide="bell-off" class="w-6 h-6 mx-auto mb-2 opacity-50"></i>
          <p>Nenhuma notificação no momento.</p>
        </div>
      `;
      return;
    }

    listContainer.innerHTML = notifs.map(n => `
      <div class="p-3 hover:bg-slate-50 transition flex items-start gap-2.5 ${n.read ? 'opacity-70' : 'bg-sky-50/40 font-medium'}">
        <div class="mt-0.5 w-2 h-2 rounded-full ${n.read ? 'bg-slate-300' : 'bg-sky-600'} flex-shrink-0"></div>
        <div class="flex-grow">
          <p class="text-xs font-bold text-slate-900">${this.escapeHtml(n.title)}</p>
          <p class="text-[11px] text-slate-600 mt-0.5 leading-snug">${this.escapeHtml(n.message)}</p>
          <span class="text-[9px] text-slate-400 mt-1 block">${this.formatDate(n.createdAt)}</span>
        </div>
        ${n.quoteId ? `
          <button onclick="app.viewQuoteDetails('${n.quoteId}')" class="text-xs text-sky-600 font-bold hover:underline flex-shrink-0">
            Ver
          </button>
        ` : ''}
      </div>
    `).join('');
  }

  // --- RENDERIZAÇÃO DO PAINEL DO CLIENTE (Com Rastreamento) ---
  renderClientDashboard() {
    const user = window.logixStore.currentUser;
    if (!user) return;

    document.getElementById('client-profile-name').textContent = user.name;
    document.getElementById('client-profile-email').textContent = user.email;
    document.getElementById('client-profile-phone').textContent = user.phone || 'Sem telefone informado';

    const myQuotes = window.logixStore.quotes.filter(q => q.clientId === user.id);
    
    // Cotações ativas ou em andamento de entrega (inclui ACEPTADA para que o cliente acompanhe a entrega!)
    const activeQuotes = myQuotes.filter(q => ['PENDIENTE_ANALISIS', 'PROPUESTA_ENVIADA', 'REANALISIS_SOLICITADO', 'ACEPTADA'].includes(q.status));
    const historyQuotes = myQuotes.filter(q => ['COMPLETADO', 'DENEGADA'].includes(q.status));

    document.getElementById('client-proposals-count').textContent = activeQuotes.length;
    document.getElementById('client-history-count').textContent = historyQuotes.length;

    const activeContainer = document.getElementById('client-active-quotes-list');
    if (activeQuotes.length === 0) {
      activeContainer.innerHTML = `
        <div class="bg-white p-12 text-center rounded-2xl border border-slate-200 shadow-sm">
          <div class="w-16 h-16 bg-sky-50 text-sky-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <i data-lucide="package" class="w-8 h-8"></i>
          </div>
          <h3 class="text-base font-bold text-slate-900">Você não tem cotações ou entregas em andamento</h3>
          <p class="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-6">
            Inicie uma nova cotação informando volumes, medidas, anexando foto da embalagem e rotas no Brasil.
          </p>
          <button onclick="app.openQuoteFormModal()" class="px-6 py-2.5 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition inline-flex items-center gap-2">
            <i data-lucide="plus-circle" class="w-4 h-4"></i>
            Solicitar Nova Cotação com Foto
          </button>
        </div>
      `;
    } else {
      activeContainer.innerHTML = activeQuotes.map(q => this.buildClientActiveQuoteCard(q)).join('');
    }

    // Histórico finalizado
    const historyTable = document.getElementById('client-history-table-body');
    if (historyQuotes.length === 0) {
      historyTable.innerHTML = `
        <tr>
          <td colspan="8" class="p-8 text-center text-slate-400">
            Nenhum serviço arquivado no histórico finalizado.
          </td>
        </tr>
      `;
    } else {
      historyTable.innerHTML = historyQuotes.map(q => `
        <tr class="hover:bg-slate-50 transition">
          <td class="p-3.5 font-mono font-bold text-slate-900">
            ${q.id}
            <span class="block font-sans text-[10px] text-slate-400 font-normal">${this.formatDate(q.createdAt)}</span>
          </td>
          <td class="p-3.5">
            ${q.packageImage ? `<img src="${q.packageImage}" alt="Carga" class="w-9 h-9 object-cover rounded border border-slate-200 shadow-xs cursor-pointer" onclick="window.open('${q.packageImage}', '_blank')">` : '<span class="text-[10px] text-slate-400">Sem foto</span>'}
          </td>
          <td class="p-3.5">
            ${this.buildModalityBadge(q.modality)}
          </td>
          <td class="p-3.5">
            <span class="font-medium text-slate-800">${this.escapeHtml(q.origin)}</span>
            <span class="text-slate-400 mx-1">➔</span>
            <span class="font-medium text-slate-800">${this.escapeHtml(q.destination)}</span>
          </td>
          <td class="p-3.5">
            <span class="font-bold text-slate-800">${q.packageCount} volume(s)</span> • ${q.weight} kg
          </td>
          <td class="p-3.5 font-bold text-slate-900">
            ${q.proposal ? this.formatCurrencyBRL(q.proposal.price) : 'N/A'}
          </td>
          <td class="p-3.5">
            ${this.buildStatusBadge(q.status, q.deliveryStage)}
          </td>
          <td class="p-3.5 text-right">
            <button onclick="app.viewQuoteDetails('${q.id}')" class="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition">
              Comprovante
            </button>
          </td>
        </tr>
      `).join('');
    }
  }

  buildClientActiveQuoteCard(quote) {
    const isProposalReady = quote.status === 'PROPUESTA_ENVIADA';
    const isPending = quote.status === 'PENDIENTE_ANALISIS';
    const isReanalysis = quote.status === 'REANALISIS_SOLICITADO';
    const isAccepted = quote.status === 'ACEPTADA';

    return `
      <div class="bg-white rounded-2xl border ${isAccepted ? 'border-emerald-300 ring-2 ring-emerald-500/15' : isProposalReady ? 'border-sky-300 ring-2 ring-sky-500/10' : 'border-slate-200'} shadow-sm overflow-hidden animate-fade-in">
        
        <!-- Cabeçalho do Card -->
        <div class="p-4 sm:p-5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div class="flex items-center gap-3">
            <div class="p-2.5 rounded-xl ${isAccepted ? 'bg-emerald-100 text-emerald-700' : isProposalReady ? 'bg-sky-100 text-sky-600' : 'bg-slate-200 text-slate-600'}">
              <i data-lucide="${quote.modality === 'aereo' ? 'plane' : 'truck'}" class="w-5 h-5"></i>
            </div>
            <div>
              <div class="flex items-center gap-2 flex-wrap">
                <h4 class="font-bold text-slate-900 text-sm">Código ${quote.id}</h4>
                ${this.buildModalityBadge(quote.modality)}
                ${this.buildStatusBadge(quote.status, quote.deliveryStage)}
              </div>
              <p class="text-[11px] text-slate-500 mt-0.5">Criado em ${this.formatDate(quote.createdAt)}</p>
            </div>
          </div>

          <div class="flex items-center gap-2">
            <button onclick="app.viewQuoteDetails('${quote.id}')" class="px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 transition flex items-center gap-1">
              <i data-lucide="eye" class="w-3.5 h-3.5"></i> Ver Ficha Completa
            </button>
          </div>
        </div>

        <!-- Dados da Carga com Miniatura da Foto -->
        <div class="p-5 grid sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs border-b border-slate-100 bg-white">
          <div class="flex items-start gap-3">
            ${quote.packageImage ? `
              <img src="${quote.packageImage}" alt="Foto da Embalagem" class="w-14 h-14 object-cover rounded-lg border border-slate-200 shadow-sm flex-shrink-0 cursor-pointer" onclick="window.open('${quote.packageImage}', '_blank')" title="Clique para ampliar a foto da caixa">
            ` : `
              <div class="w-14 h-14 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-400 flex-shrink-0">
                <i data-lucide="image" class="w-6 h-6"></i>
              </div>
            `}
            <div>
              <span class="text-slate-400 text-[10px] uppercase font-bold block">Rota de Transporte</span>
              <p class="font-semibold text-slate-800 mt-0.5">${this.escapeHtml(quote.origin)}</p>
              <p class="text-slate-400 text-[10px] my-0.5">para</p>
              <p class="font-semibold text-slate-800">${this.escapeHtml(quote.destination)}</p>
            </div>
          </div>

          <div>
            <span class="text-slate-400 text-[10px] uppercase font-bold block">Volumes & Dimensões</span>
            <p class="font-semibold text-slate-800 mt-0.5">${quote.packageCount} volume(s) / ${quote.weight} kg</p>
            <p class="text-slate-500 text-[11px] mt-0.5">Medidas: ${quote.dimensions.length} x ${quote.dimensions.width} x ${quote.dimensions.height} cm</p>
            <p class="text-slate-400 text-[10px]">Cubagem: ${(quote.dimensions.volumeCm3 / 1000).toFixed(1)} dm³</p>
          </div>

          <div>
            <span class="text-slate-400 text-[10px] uppercase font-bold block">Mercadoria</span>
            <p class="text-slate-700 mt-0.5">${this.escapeHtml(quote.description)}</p>
            ${quote.isFragile ? '<span class="inline-block mt-1 px-2 py-0.5 bg-red-50 text-red-700 rounded text-[10px] font-bold border border-red-200">Mercadoria Frágil</span>' : ''}
          </div>

          <div>
            <span class="text-slate-400 text-[10px] uppercase font-bold block">Situação do Pedido</span>
            ${isPending ? `
              <div class="mt-1 p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-[11px]">
                <i data-lucide="hourglass" class="w-3.5 h-3.5 inline mr-1 text-amber-600"></i>
                <strong>Cotação de envio sujeita a análise</strong>. Analisando foto e cubagem da caixa.
              </div>
            ` : ''}
            ${isReanalysis ? `
              <div class="mt-1 p-2.5 rounded-lg bg-orange-50 border border-orange-200 text-orange-900 text-[11px]">
                <i data-lucide="refresh-cw" class="w-3.5 h-3.5 inline mr-1 text-orange-600"></i>
                Reanálise solicitada. A equipe Top 10 Cargas está revisando seus comentários.
              </div>
            ` : ''}
            ${isProposalReady ? `
              <div class="mt-1 p-2.5 rounded-lg bg-sky-50 border border-sky-200 text-sky-900 text-[11px]">
                <i data-lucide="check-circle" class="w-3.5 h-3.5 inline mr-1 text-sky-600"></i>
                <strong>Proposta comercial disponível!</strong> Avalie e tome uma decisão abaixo.
              </div>
            ` : ''}
            ${isAccepted ? `
              <div class="mt-1 p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-900 text-[11px]">
                <i data-lucide="truck" class="w-3.5 h-3.5 inline mr-1 text-emerald-600"></i>
                <strong>Proposta Aceita!</strong> Acompanhe abaixo o rastreamento do envio.
              </div>
            ` : ''}
          </div>
        </div>

        <!-- RASTREADOR DE ENTREGA EM TEMPO REAL (Para pedidos Aceitos) -->
        ${isAccepted ? this.buildDeliveryTrackingStepper(quote) : ''}

        <!-- SEÇÃO DA PROPOSTA EM BRL COM AS 3 AÇÕES (Para propostas aguardando resposta) -->
        ${isProposalReady ? `
          <div class="p-5 bg-gradient-to-br from-sky-50/70 to-blue-50/70 border-t border-sky-200">
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              
              <div class="space-y-1">
                <div class="flex items-baseline gap-2">
                  <span class="text-xs font-bold uppercase tracking-wider text-sky-700">Valor da Proposta:</span>
                  <span class="text-2xl font-black text-slate-900">${this.formatCurrencyBRL(quote.proposal.price)}</span>
                  <span class="text-xs text-slate-600 font-medium">(${quote.proposal.estimatedTime})</span>
                </div>
                <p class="text-xs text-slate-600 mt-1">
                  <strong>Condições do Operador:</strong> ${this.escapeHtml(quote.proposal.notes || 'Frete porta a porta conforme imagem e especificações técnicas.')}
                </p>
                <div class="flex items-center gap-3 text-[11px] text-slate-500 pt-1">
                  <span>Frete Peso: ${this.formatCurrencyBRL(quote.proposal.breakdown.base)}</span>
                  <span>•</span>
                  <span>Seguro: ${this.formatCurrencyBRL(quote.proposal.breakdown.insurance)}</span>
                  <span>•</span>
                  <span>Taxas/Coleta: ${this.formatCurrencyBRL(quote.proposal.breakdown.packaging)}</span>
                </div>
              </div>

              <!-- AS 3 AÇÕES DISPONÍVEIS -->
              <div class="flex items-center gap-2 flex-wrap">
                <button onclick="app.actionAcceptProposal('${quote.id}')" class="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition flex items-center gap-1.5">
                  <i data-lucide="check-circle-2" class="w-4 h-4"></i>
                  Aceitar Proposta
                </button>
                <button onclick="app.openDenyModal('${quote.id}')" class="px-3.5 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs uppercase tracking-wider rounded-xl transition flex items-center gap-1.5">
                  <i data-lucide="x-circle" class="w-4 h-4"></i>
                  Recusar
                </button>
                <button onclick="app.openReanalysisModal('${quote.id}')" class="px-3.5 py-2.5 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 font-bold text-xs uppercase tracking-wider rounded-xl transition flex items-center gap-1.5">
                  <i data-lucide="refresh-cw" class="w-4 h-4"></i>
                  Solicitar Outra Análise
                </button>
              </div>

            </div>
          </div>
        ` : ''}

      </div>
    `;
  }

  // Stepper Visual de Rastreamento de Entrega
  buildDeliveryTrackingStepper(quote) {
    const stage = quote.deliveryStage || 'aguardando_coleta';
    
    const isStep1 = true; // Proposta Aceita
    const isStep2 = ['aguardando_coleta', 'em_transito', 'saiu_entrega', 'entregue'].includes(stage);
    const isStep3 = ['em_transito', 'saiu_entrega', 'entregue'].includes(stage);
    const isStep4 = stage === 'entregue';

    let currentStatusText = 'Aguardando agendamento de coleta no remetente.';
    let statusClass = 'text-amber-700 bg-amber-50 border-amber-200';
    let iconName = 'clock';

    if (stage === 'em_transito') {
      currentStatusText = 'Carga coletada e em deslocamento! A mercadoria está a caminho do destino.';
      statusClass = 'text-sky-800 bg-sky-50 border-sky-200 animate-pulse';
      iconName = 'truck';
    } else if (stage === 'saiu_entrega') {
      currentStatusText = 'Saiu para entrega! O veículo está em rota final para entrega ao destinatário.';
      statusClass = 'text-purple-800 bg-purple-50 border-purple-200 animate-pulse';
      iconName = 'map-pin';
    } else if (stage === 'entregue') {
      currentStatusText = 'Entrega concluída com sucesso! Pacote entregue com canhoto assinado.';
      statusClass = 'text-emerald-800 bg-emerald-50 border-emerald-200';
      iconName = 'check-circle-2';
    }

    return `
      <div class="p-5 bg-slate-50/80 border-t border-slate-200 space-y-4">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <i data-lucide="navigation-2" class="w-4 h-4 text-emerald-600"></i>
            <h5 class="font-bold text-xs uppercase tracking-wider text-slate-800">Acompanhamento de Entrega em Tempo Real</h5>
          </div>
          <span class="text-xs font-bold px-3 py-1 rounded-full border ${statusClass} flex items-center gap-1.5">
            <i data-lucide="${iconName}" class="w-3.5 h-3.5"></i>
            ${stage === 'em_transito' ? 'A Caminho / Em Trânsito' : stage === 'saiu_entrega' ? 'Saiu para Entrega' : stage === 'entregue' ? 'Entregue' : 'Aguardando Coleta'}
          </span>
        </div>

        <p class="text-xs text-slate-600 italic">
          "${currentStatusText}"
        </p>

        <!-- Stepper Visual -->
        <div class="relative py-2">
          <div class="absolute top-1/2 left-4 right-4 h-1 bg-slate-200 -translate-y-1/2 z-0"></div>
          <div class="absolute top-1/2 left-4 h-1 bg-emerald-500 -translate-y-1/2 z-0 transition-all duration-500" style="width: ${isStep4 ? '100%' : isStep3 ? '66%' : isStep2 ? '33%' : '0%'}"></div>

          <div class="relative z-10 grid grid-cols-4 text-center">
            <!-- Passo 1 -->
            <div class="flex flex-col items-center">
              <div class="w-8 h-8 rounded-full bg-emerald-500 text-white font-bold text-xs flex items-center justify-center shadow-md">
                <i data-lucide="check" class="w-4 h-4"></i>
              </div>
              <span class="text-[11px] font-bold text-slate-800 mt-1.5">1. Aprovado</span>
              <span class="text-[9px] text-slate-400">Proposta aceita</span>
            </div>

            <!-- Passo 2 -->
            <div class="flex flex-col items-center">
              <div class="w-8 h-8 rounded-full ${isStep2 ? 'bg-emerald-500 text-white' : 'bg-slate-300 text-slate-600'} font-bold text-xs flex items-center justify-center shadow-md">
                <i data-lucide="package" class="w-4 h-4"></i>
              </div>
              <span class="text-[11px] font-bold ${isStep2 ? 'text-slate-800' : 'text-slate-400'} mt-1.5">2. Coleta</span>
              <span class="text-[9px] text-slate-400">No remetente</span>
            </div>

            <!-- Passo 3 -->
            <div class="flex flex-col items-center">
              <div class="w-8 h-8 rounded-full ${isStep3 ? 'bg-emerald-500 text-white' : 'bg-slate-300 text-slate-600'} font-bold text-xs flex items-center justify-center shadow-md">
                <i data-lucide="truck" class="w-4 h-4"></i>
              </div>
              <span class="text-[11px] font-bold ${isStep3 ? 'text-slate-800' : 'text-slate-400'} mt-1.5">3. Em Trânsito</span>
              <span class="text-[9px] text-slate-400">A caminho</span>
            </div>

            <!-- Passo 4 -->
            <div class="flex flex-col items-center">
              <div class="w-8 h-8 rounded-full ${isStep4 ? 'bg-emerald-500 text-white' : 'bg-slate-300 text-slate-600'} font-bold text-xs flex items-center justify-center shadow-md">
                <i data-lucide="award" class="w-4 h-4"></i>
              </div>
              <span class="text-[11px] font-bold ${isStep4 ? 'text-slate-800' : 'text-slate-400'} mt-1.5">4. Entregue</span>
              <span class="text-[9px] text-slate-400">Destino final</span>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // --- RENDERIZAÇÃO DO PAINEL DO ADMINISTRADOR (Top 10 Cargas) ---
  renderAdminDashboard() {
    const allQuotes = window.logixStore.quotes;

    const pendingQuotes = allQuotes.filter(q => q.status === 'PENDIENTE_ANALISIS' || q.status === 'REANALISIS_SOLICITADO');
    const sentQuotes = allQuotes.filter(q => q.status === 'PROPUESTA_ENVIADA');
    const acceptedQuotes = allQuotes.filter(q => q.status === 'ACEPTADA');
    const completedQuotes = allQuotes.filter(q => q.status === 'COMPLETADO');

    const totalRevenue = allQuotes
      .filter(q => q.status === 'ACEPTADA' || q.status === 'COMPLETADO')
      .reduce((sum, q) => sum + (q.proposal ? q.proposal.price : 0), 0);

    document.getElementById('kpi-pending-count').textContent = pendingQuotes.length;
    document.getElementById('kpi-sent-count').textContent = sentQuotes.length;
    document.getElementById('kpi-accepted-count').textContent = acceptedQuotes.length;
    document.getElementById('kpi-total-revenue').textContent = this.formatCurrencyBRL(totalRevenue);

    document.getElementById('admin-pending-badge').textContent = pendingQuotes.length;
    document.getElementById('admin-active-badge').textContent = acceptedQuotes.length;
    document.getElementById('admin-history-badge').textContent = allQuotes.length;

    // Aba 1: Pendentes
    const pendingContainer = document.getElementById('admin-pending-quotes-container');
    if (pendingQuotes.length === 0) {
      pendingContainer.innerHTML = `
        <div class="bg-white p-12 text-center rounded-2xl border border-slate-200">
          <i data-lucide="check-circle" class="w-12 h-12 text-emerald-500 mx-auto mb-3"></i>
          <h4 class="font-bold text-slate-800 text-base">Fila de cotações em dia!</h4>
          <p class="text-xs text-slate-400 mt-1">Nenhuma solicitação pendente de análise no momento.</p>
        </div>
      `;
    } else {
      pendingContainer.innerHTML = pendingQuotes.map(q => this.buildAdminPendingQuoteCard(q)).join('');
    }

    // Aba 2: Gestão de Entregas e Rastreamento Ativo
    const activeContainer = document.getElementById('admin-accepted-quotes-container');
    if (acceptedQuotes.length === 0) {
      activeContainer.innerHTML = `
        <div class="bg-white p-12 text-center rounded-2xl border border-slate-200">
          <i data-lucide="truck" class="w-12 h-12 text-slate-400 mx-auto mb-3"></i>
          <h4 class="font-bold text-slate-800 text-base">Nenhuma entrega em rota no momento</h4>
          <p class="text-xs text-slate-400 mt-1">Quando os clientes aceitarem suas propostas, elas aparecerão aqui com a foto da carga para avanço de status.</p>
        </div>
      `;
    } else {
      activeContainer.innerHTML = acceptedQuotes.map(q => `
        <div class="bg-white p-5 rounded-2xl border border-emerald-200 shadow-sm flex flex-col lg:flex-row lg:items-center justify-between gap-4 animate-fade-in">
          <div class="flex items-start gap-3">
            ${q.packageImage ? `
              <img src="${q.packageImage}" alt="Foto da Carga" class="w-16 h-16 object-cover rounded-xl border border-slate-300 shadow-sm flex-shrink-0 cursor-pointer" onclick="window.open('${q.packageImage}', '_blank')" title="Clique para ampliar foto">
            ` : `
              <div class="w-16 h-16 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-400 flex-shrink-0">
                <i data-lucide="package" class="w-8 h-8"></i>
              </div>
            `}
            <div class="space-y-1">
              <div class="flex items-center gap-2 flex-wrap">
                <span class="font-mono font-bold text-slate-900">${q.id}</span>
                ${this.buildModalityBadge(q.modality)}
                ${this.buildStatusBadge(q.status, q.deliveryStage)}
              </div>
              <p class="text-xs font-semibold text-slate-800">
                Cliente: ${this.escapeHtml(q.clientName)} (${q.clientPhone || q.clientEmail})
              </p>
              <p class="text-xs text-slate-600">
                Trajeto: <strong>${this.escapeHtml(q.origin)}</strong> ➔ <strong>${this.escapeHtml(q.destination)}</strong>
              </p>
              <p class="text-xs text-emerald-700 font-bold">
                Valor Fechado: ${this.formatCurrencyBRL(q.proposal.price)} | ${q.packageCount} volume(s) (${q.weight} kg)
              </p>
            </div>
          </div>

          <!-- Ações do Administrador para Atualizar Rastreamento -->
          <div class="flex flex-col sm:flex-row items-center gap-2 flex-shrink-0">
            <span class="text-[10px] uppercase font-bold text-slate-400 hidden sm:inline">Mudar Etapa:</span>
            
            <button onclick="app.actionUpdateDeliveryStage('${q.id}', 'em_transito')" title="Marcar como carga coletada e em trânsito" class="px-3 py-1.5 ${q.deliveryStage === 'em_transito' ? 'bg-sky-600 text-white' : 'bg-slate-100 hover:bg-sky-50 text-sky-800 border border-slate-200'} text-xs font-bold rounded-lg transition flex items-center gap-1">
              <i data-lucide="truck" class="w-3.5 h-3.5"></i> A Caminho
            </button>

            <button onclick="app.actionUpdateDeliveryStage('${q.id}', 'saiu_entrega')" title="Marcar como veículo em rota de entrega final" class="px-3 py-1.5 ${q.deliveryStage === 'saiu_entrega' ? 'bg-purple-600 text-white' : 'bg-slate-100 hover:bg-purple-50 text-purple-800 border border-slate-200'} text-xs font-bold rounded-lg transition flex items-center gap-1">
              <i data-lucide="map-pin" class="w-3.5 h-3.5"></i> Saiu p/ Entrega
            </button>

            <button onclick="app.actionUpdateDeliveryStage('${q.id}', 'entregue')" title="Confirmar que foi entregue com canhoto assinado" class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow transition flex items-center gap-1">
              <i data-lucide="check" class="w-3.5 h-3.5"></i> Entregue
            </button>

            <button onclick="app.viewQuoteDetails('${q.id}')" class="p-1.5 text-slate-500 hover:text-slate-800" title="Ver Comprovante">
              <i data-lucide="file-text" class="w-4 h-4"></i>
            </button>
          </div>
        </div>
      `).join('');
    }

    // Aba 3: Histórico Geral
    this.filterAdminHistory();
  }

  buildAdminPendingQuoteCard(quote) {
    const isReanalysis = quote.status === 'REANALISIS_SOLICITADO';
    return `
      <div class="bg-white rounded-2xl border ${isReanalysis ? 'border-orange-300 ring-2 ring-orange-500/10' : 'border-slate-200'} shadow-sm p-6 animate-fade-in">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div class="flex items-center gap-3">
            <div class="p-2.5 rounded-xl ${isReanalysis ? 'bg-orange-100 text-orange-600' : 'bg-amber-100 text-amber-600'}">
              <i data-lucide="${isReanalysis ? 'refresh-cw' : 'clipboard-list'}" class="w-5 h-5"></i>
            </div>
            <div>
              <div class="flex items-center gap-2">
                <span class="font-mono font-bold text-slate-900">${quote.id}</span>
                ${this.buildModalityBadge(quote.modality)}
                ${this.buildStatusBadge(quote.status, quote.deliveryStage)}
              </div>
              <p class="text-xs text-slate-500 mt-0.5">
                Cliente: <strong class="text-slate-800">${this.escapeHtml(quote.clientName)}</strong> • Tel: ${this.escapeHtml(quote.clientPhone || 'N/A')} • E-mail: ${this.escapeHtml(quote.clientEmail)}
              </p>
            </div>
          </div>

          <button onclick="app.openAdminProposalModal('${quote.id}')" class="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition flex items-center gap-2">
            <i data-lucide="calculator" class="w-4 h-4 text-amber-400"></i>
            ${isReanalysis ? 'Reanalisar & Enviar Nova Proposta' : 'Calcular & Enviar Proposta'}
          </button>
        </div>

        ${isReanalysis ? `
          <div class="my-3 p-3 bg-orange-50 border border-orange-200 rounded-xl text-xs text-orange-900 flex items-start gap-2">
            <i data-lucide="message-square" class="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0"></i>
            <div>
              <strong class="font-bold">Observações do Cliente para Reanálise:</strong>
              <p class="italic mt-0.5">"${this.escapeHtml(quote.reanalysisNotes)}"</p>
            </div>
          </div>
        ` : ''}

        <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs pt-4">
          <div class="flex items-start gap-3">
            ${quote.packageImage ? `
              <img src="${quote.packageImage}" alt="Foto da Carga" class="w-14 h-14 object-cover rounded-lg border border-slate-300 shadow-sm flex-shrink-0 cursor-pointer" onclick="window.open('${quote.packageImage}', '_blank')" title="Clique para ver a foto ampliada">
            ` : '<div class="w-14 h-14 rounded bg-slate-100 text-slate-400 flex items-center justify-center text-[10px] text-center flex-shrink-0">Sem foto</div>'}
            <div>
              <span class="text-slate-400 text-[10px] uppercase font-bold block">Rota Solicitada</span>
              <p class="font-semibold text-slate-800 mt-0.5">De: ${this.escapeHtml(quote.origin)}</p>
              <p class="font-semibold text-slate-800">Para: ${this.escapeHtml(quote.destination)}</p>
            </div>
          </div>

          <div>
            <span class="text-slate-400 text-[10px] uppercase font-bold block">Dados da Carga</span>
            <p class="font-semibold text-slate-800 mt-0.5">Volumes: <strong class="text-sky-600">${quote.packageCount} volume(s)</strong></p>
            <p class="text-slate-700">Peso Real: <strong>${quote.weight} kg</strong></p>
            <p class="text-slate-700">Dimensões: ${quote.dimensions.length} x ${quote.dimensions.width} x ${quote.dimensions.height} cm</p>
          </div>

          <div>
            <span class="text-slate-400 text-[10px] uppercase font-bold block">Cubagem & Fator de Cálculo</span>
            <p class="text-slate-700 mt-0.5">Volume Total: <strong>${(quote.dimensions.volumeCm3 / 1000).toFixed(1)} dm³</strong></p>
            <p class="text-slate-700">Peso Cubado: <strong>${((quote.dimensions.length * quote.dimensions.width * quote.dimensions.height) / (quote.modality === 'aereo' ? 6000 : 5000)).toFixed(1)} kg</strong></p>
            <p class="text-slate-500 text-[10px]">Valor Declarado: ${this.formatCurrencyBRL(quote.declaredValue || 0)}</p>
          </div>

          <div>
            <span class="text-slate-400 text-[10px] uppercase font-bold block">Mercadoria & Segurança</span>
            <p class="text-slate-800 mt-0.5">${this.escapeHtml(quote.description)}</p>
            ${quote.isFragile ? '<span class="inline-block mt-1 px-2 py-0.5 bg-red-100 text-red-800 rounded text-[10px] font-bold">Carga Frágil</span>' : '<span class="text-slate-400 text-[10px]">Carga Convencional</span>'}
          </div>
        </div>
      </div>
    `;
  }

  filterAdminHistory() {
    const search = (document.getElementById('admin-history-search')?.value || '').toLowerCase().trim();
    const statusFilter = document.getElementById('admin-history-filter-status')?.value || 'ALL';
    const tbody = document.getElementById('admin-history-table-body');
    if (!tbody) return;

    let quotes = window.logixStore.quotes;

    if (statusFilter !== 'ALL') {
      quotes = quotes.filter(q => q.status === statusFilter);
    }

    if (search) {
      quotes = quotes.filter(q => 
        q.id.toLowerCase().includes(search) ||
        q.clientName.toLowerCase().includes(search) ||
        q.origin.toLowerCase().includes(search) ||
        q.destination.toLowerCase().includes(search)
      );
    }

    if (quotes.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="9" class="p-8 text-center text-slate-400">
            Nenhum registro encontrado com os critérios selecionados.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = quotes.map(q => `
      <tr class="hover:bg-slate-50 transition">
        <td class="p-3.5 font-mono font-bold text-slate-900">
          ${q.id}
          <span class="block font-sans text-[10px] text-slate-400 font-normal">${this.formatDate(q.createdAt)}</span>
        </td>
        <td class="p-3.5">
          ${q.packageImage ? `<img src="${q.packageImage}" alt="Carga" class="w-10 h-10 object-cover rounded border border-slate-200 cursor-pointer shadow-xs" onclick="window.open('${q.packageImage}', '_blank')">` : '<span class="text-[10px] text-slate-400">Sem foto</span>'}
        </td>
        <td class="p-3.5">
          <span class="font-bold text-slate-800 block">${this.escapeHtml(q.clientName)}</span>
          <span class="text-[10px] text-slate-400">${this.escapeHtml(q.clientPhone || q.clientEmail)}</span>
        </td>
        <td class="p-3.5">
          ${this.buildModalityBadge(q.modality)}
        </td>
        <td class="p-3.5 text-[11px]">
          <span class="text-slate-700">${this.escapeHtml(q.origin)}</span>
          <span class="text-slate-400 block">➔ ${this.escapeHtml(q.destination)}</span>
        </td>
        <td class="p-3.5 text-[11px]">
          <span class="font-bold text-slate-800">${q.packageCount} volume(s)</span> • ${q.weight} kg
          <span class="block text-[10px] text-slate-400">${q.dimensions.length}x${q.dimensions.width}x${q.dimensions.height} cm</span>
        </td>
        <td class="p-3.5">
          ${q.proposal ? `
            <span class="font-bold text-slate-900 block">${this.formatCurrencyBRL(q.proposal.price)}</span>
            <span class="text-[10px] text-slate-500">${this.escapeHtml(q.proposal.estimatedTime)}</span>
          ` : '<span class="text-slate-400 italic">Sem proposta</span>'}
        </td>
        <td class="p-3.5">
          ${this.buildStatusBadge(q.status, q.deliveryStage)}
        </td>
        <td class="p-3.5 text-right">
          <button onclick="app.viewQuoteDetails('${q.id}')" class="p-1.5 hover:bg-slate-200 text-slate-600 rounded-md transition" title="Ver Comprovante Oficial">
            <i data-lucide="file-text" class="w-4 h-4"></i>
          </button>
        </td>
      </tr>
    `).join('');

    lucide.createIcons();
  }

  // --- UPLOAD DE IMAGEM DA CAIXA ---
  handleImageSelected(e) {
    const file = e.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Por favor, selecione um arquivo de imagem válido (JPG, PNG, WebP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      this.currentUploadedImage = event.target.result;
      const preview = document.getElementById('quote-image-preview');
      const container = document.getElementById('quote-image-preview-container');
      if (preview && container) {
        preview.src = this.currentUploadedImage;
        container.classList.remove('hidden');
      }
    };
    reader.readAsDataURL(file);
  }

  removeSelectedImage() {
    this.currentUploadedImage = null;
    const fileInput = document.getElementById('quote-package-image-file');
    const container = document.getElementById('quote-image-preview-container');
    if (fileInput) fileInput.value = '';
    if (container) container.classList.add('hidden');
  }

  // --- MODAL DE COTAÇÃO ---
  openQuoteFormModal(prefill = {}) {
    document.getElementById('modal-quote-form').classList.remove('hidden');
    
    if (prefill.modality) {
      if (prefill.modality === 'aereo') {
        const radAereo = document.getElementById('modal-mod-aereo');
        if (radAereo) radAereo.checked = true;
      } else {
        const radRodo = document.getElementById('modal-mod-rodoviario');
        if (radRodo) radRodo.checked = true;
      }
    }

    if (prefill.origin) document.getElementById('quote-origin').value = prefill.origin;
    if (prefill.destination) document.getElementById('quote-destination').value = prefill.destination;
    if (prefill.packageCount) document.getElementById('quote-package-count').value = prefill.packageCount;
    if (prefill.weight) document.getElementById('quote-weight').value = prefill.weight;

    if (prefill.preset) {
      if (prefill.preset === 'pequeno') {
        document.getElementById('quote-length').value = 25;
        document.getElementById('quote-width').value = 20;
        document.getElementById('quote-height').value = 15;
      } else if (prefill.preset === 'mediano') {
        document.getElementById('quote-length').value = 40;
        document.getElementById('quote-width').value = 30;
        document.getElementById('quote-height').value = 25;
      } else if (prefill.preset === 'grande') {
        document.getElementById('quote-length').value = 70;
        document.getElementById('quote-width').value = 50;
        document.getElementById('quote-height').value = 45;
      }
    }

    this.calculateVolumePreview();
    lucide.createIcons();
  }

  closeQuoteFormModal() {
    document.getElementById('modal-quote-form').classList.add('hidden');
  }

  calculateVolumePreview() {
    const l = parseFloat(document.getElementById('quote-length').value) || 0;
    const w = parseFloat(document.getElementById('quote-width').value) || 0;
    const h = parseFloat(document.getElementById('quote-height').value) || 0;
    const volCm3 = l * w * h;
    const volM3 = volCm3 / 1000000;
    const volWeight = (volCm3 / 5000).toFixed(2);

    const preview = document.getElementById('volume-preview-text');
    if (preview) {
      preview.textContent = `Cubagem calculada: ${volCm3.toLocaleString('pt-BR')} cm³ (${volM3.toFixed(3)} m³) • Peso cubado estimado: ${volWeight} kg`;
    }
  }

  handleHeroFormSubmit(e) {
    e.preventDefault();
    const modality = document.querySelector('input[name="hero-modality"]:checked')?.value || 'rodoviario';
    const origin = document.getElementById('hero-origin').value;
    const destination = document.getElementById('hero-destination').value;
    const count = document.getElementById('hero-count').value;
    const weight = document.getElementById('hero-weight').value;
    const preset = document.getElementById('hero-size-preset').value;

    this.openQuoteFormModal({
      modality,
      origin,
      destination,
      packageCount: count,
      weight,
      preset
    });
  }

  actionStartQuote() {
    this.openQuoteFormModal();
  }

  handleQuoteSubmit(e) {
    e.preventDefault();

    const modality = document.querySelector('input[name="quote-modality"]:checked')?.value || 'rodoviario';

    const data = {
      modality: modality,
      packageCount: document.getElementById('quote-package-count').value,
      length: document.getElementById('quote-length').value,
      width: document.getElementById('quote-width').value,
      height: document.getElementById('quote-height').value,
      weight: document.getElementById('quote-weight').value,
      packageImage: this.currentUploadedImage || null, // Imagem da caixa enviada pelo cliente
      origin: document.getElementById('quote-origin').value,
      destination: document.getElementById('quote-destination').value,
      declaredValue: document.getElementById('quote-declared-value').value,
      description: document.getElementById('quote-description').value,
      isFragile: document.getElementById('quote-is-fragile').checked
    };

    const createdQuote = window.logixStore.createQuote(data);

    this.closeQuoteFormModal();
    document.getElementById('form-new-quote').reset();
    this.removeSelectedImage();

    // Modal Obrigatório Oficial
    this.showSujetaAnalisisModal(createdQuote.id);
  }

  showSujetaAnalisisModal(quoteId) {
    document.getElementById('modal-sujeta-folio').textContent = quoteId;
    document.getElementById('modal-sujeta-analisis').classList.remove('hidden');
    lucide.createIcons();
  }

  closeSujetaAnalisisModal(goToDashboard = false) {
    document.getElementById('modal-sujeta-analisis').classList.add('hidden');
    if (goToDashboard) {
      if (!window.logixStore.currentUser) {
        window.logixStore.switchRole('client');
      }
      this.navigateTo('client_dashboard');
      this.setClientTab('proposals');
    }
  }

  // --- ADMINISTRADOR: MODAL DE PROPOSTA COM VISUALIZAÇÃO DE FOTO ---
  openAdminProposalModal(quoteId) {
    const quote = window.logixStore.quotes.find(q => q.id === quoteId);
    if (!quote) return;

    this.currentQuoteForAction = quote;
    document.getElementById('admin-modal-quote-id').textContent = quote.id;
    document.getElementById('admin-view-client').textContent = `${quote.clientName} (${quote.clientPhone || quote.clientEmail})`;
    document.getElementById('admin-view-packages').textContent = `${quote.packageCount} volume(s)`;
    document.getElementById('admin-view-weight').textContent = quote.weight;
    document.getElementById('admin-view-dimensions').textContent = `${quote.dimensions.length}x${quote.dimensions.width}x${quote.dimensions.height} cm`;
    document.getElementById('admin-view-origin').textContent = quote.origin;
    document.getElementById('admin-view-destination').textContent = quote.destination;

    // Foto da Carga
    const imageBox = document.getElementById('admin-view-image-box');
    const imagePreview = document.getElementById('admin-view-image-preview');
    if (quote.packageImage) {
      imagePreview.src = quote.packageImage;
      imageBox.classList.remove('hidden');
    } else {
      imagePreview.src = 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=400&q=80';
      imageBox.classList.remove('hidden');
    }

    const modBadge = document.getElementById('admin-view-modality-badge');
    if (modBadge) {
      modBadge.textContent = quote.modality === 'aereo' ? 'Frete Aéreo Express' : 'Rodoviário Nacional';
      modBadge.className = quote.modality === 'aereo' 
        ? 'px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800'
        : 'px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800';
    }

    const reanalysisBox = document.getElementById('admin-view-reanalysis-box');
    const reanalysisText = document.getElementById('admin-view-reanalysis-text');
    if (quote.reanalysisNotes) {
      reanalysisText.textContent = quote.reanalysisNotes;
      reanalysisBox.classList.remove('hidden');
    } else {
      reanalysisBox.classList.add('hidden');
    }

    if (quote.proposal) {
      document.getElementById('admin-proposal-price').value = quote.proposal.price;
      document.getElementById('admin-proposal-eta').value = quote.proposal.estimatedTime;
      document.getElementById('admin-proposal-base').value = quote.proposal.breakdown.base;
      document.getElementById('admin-proposal-insurance').value = quote.proposal.breakdown.insurance;
      document.getElementById('admin-proposal-packaging').value = quote.proposal.breakdown.packaging;
      document.getElementById('admin-proposal-notes').value = quote.proposal.notes;
    } else {
      const mult = quote.modality === 'aereo' ? 18 : 8;
      const suggestedBase = Math.max(90, Math.round(quote.weight * mult + (quote.dimensions.volumeCm3 / 5000) * 12));
      const suggestedInsurance = quote.declaredValue ? Math.round(quote.declaredValue * 0.015) : 35;
      const suggestedPackaging = quote.isFragile ? 40 : 20;
      const suggestedTotal = suggestedBase + suggestedInsurance + suggestedPackaging;

      document.getElementById('admin-proposal-price').value = suggestedTotal;
      document.getElementById('admin-proposal-eta').value = quote.modality === 'aereo' ? '24 a 48 horas úteis (Aéreo)' : '3 a 5 dias úteis (Rodoviário)';
      document.getElementById('admin-proposal-base').value = suggestedBase;
      document.getElementById('admin-proposal-insurance').value = suggestedInsurance;
      document.getElementById('admin-proposal-packaging').value = suggestedPackaging;
      document.getElementById('admin-proposal-notes').value = 'Coleta no remetente inclusa com apólice de seguro contra extravio e rastreamento em tempo real.';
    }

    document.getElementById('modal-admin-proposal').classList.remove('hidden');
    lucide.createIcons();
  }

  closeAdminProposalModal() {
    document.getElementById('modal-admin-proposal').classList.add('hidden');
    this.currentQuoteForAction = null;
  }

  handleAdminProposalSubmit(e) {
    e.preventDefault();
    if (!this.currentQuoteForAction) return;

    const proposalData = {
      price: document.getElementById('admin-proposal-price').value,
      currency: 'BRL',
      estimatedTime: document.getElementById('admin-proposal-eta').value,
      base: document.getElementById('admin-proposal-base').value,
      insurance: document.getElementById('admin-proposal-insurance').value,
      packaging: document.getElementById('admin-proposal-packaging').value,
      notes: document.getElementById('admin-proposal-notes').value
    };

    window.logixStore.sendProposal(this.currentQuoteForAction.id, proposalData);
    this.closeAdminProposalModal();
    this.showToast('Proposta enviada ao cliente com sucesso!', 'success');
  }

  // --- CLIENTE: DECISÕES DA PROPOSTA ---
  actionAcceptProposal(quoteId) {
    if (confirm('Confirma a aprovação desta proposta? O envio será confirmado e você poderá acompanhar o rastreamento em tempo real.')) {
      window.logixStore.acceptProposal(quoteId);
      this.showToast('Você aceitou a proposta! O rastreamento de entrega já está ativo.', 'success');
    }
  }

  openDenyModal(quoteId) {
    document.getElementById('deny-quote-id').value = quoteId;
    document.getElementById('deny-reason').value = '';
    document.getElementById('modal-deny-proposal').classList.remove('hidden');
    lucide.createIcons();
  }

  closeDenyModal() {
    document.getElementById('modal-deny-proposal').classList.add('hidden');
  }

  handleDenySubmit(e) {
    e.preventDefault();
    const quoteId = document.getElementById('deny-quote-id').value;
    const reason = document.getElementById('deny-reason').value;

    window.logixStore.denyProposal(quoteId, reason);
    this.closeDenyModal();
    this.showToast('Você recusou a proposta comercial.', 'info');
  }

  openReanalysisModal(quoteId) {
    document.getElementById('reanalysis-quote-id').value = quoteId;
    document.getElementById('reanalysis-feedback').value = '';
    document.getElementById('modal-reanalysis').classList.remove('hidden');
    lucide.createIcons();
  }

  closeReanalysisModal() {
    document.getElementById('modal-reanalysis').classList.add('hidden');
  }

  handleReanalysisSubmit(e) {
    e.preventDefault();
    const quoteId = document.getElementById('reanalysis-quote-id').value;
    const feedback = document.getElementById('reanalysis-feedback').value;

    window.logixStore.requestReanalysis(quoteId, feedback);
    this.closeReanalysisModal();
    this.showToast('Solicitação de reanálise enviada à administração!', 'warning');
  }

  // --- ADMINISTRADOR: AVANÇO DE ETAPA DE RASTREAMENTO ---
  actionUpdateDeliveryStage(quoteId, stage) {
    window.logixStore.updateDeliveryStage(quoteId, stage);
    let msg = 'Status de entrega atualizado com sucesso!';
    if (stage === 'em_transito') msg = 'Status atualizado: Carga Coletada e A Caminho!';
    else if (stage === 'saiu_entrega') msg = 'Status atualizado: Saiu para Entrega!';
    else if (stage === 'entregue') msg = 'Status atualizado: Entrega Concluída com Sucesso!';
    this.showToast(msg, 'success');
  }

  // --- COMPROVANTE OFICIAL (IMPRIMÍVEL) ---
  viewQuoteDetails(quoteId) {
    const quote = window.logixStore.quotes.find(q => q.id === quoteId);
    if (!quote) return;

    const receipt = document.getElementById('printable-receipt');
    receipt.innerHTML = `
      <div class="border-b border-slate-200 pb-4 mb-4 flex items-center justify-between">
        <div>
          <h2 class="text-xl font-black text-slate-900 tracking-tight">TOP 10<span class="text-sky-600"> CARGAS BRASIL</span></h2>
          <p class="text-[10px] text-slate-500">Documento Oficial de Cotação de Transporte Nacional</p>
        </div>
        <div class="text-right">
          <p class="font-mono text-sm font-black text-slate-900">${quote.id}</p>
          <p class="text-[10px] text-slate-400">Emissão: ${this.formatDate(quote.createdAt)}</p>
        </div>
      </div>

      <div class="grid grid-cols-2 gap-4 pb-4 border-b border-slate-200">
        <div>
          <h5 class="font-bold text-slate-900 text-xs uppercase mb-1">Cliente / Solicitante:</h5>
          <p class="font-semibold text-slate-800">${this.escapeHtml(quote.clientName)}</p>
          <p class="text-slate-600">${this.escapeHtml(quote.clientEmail)}</p>
          <p class="text-slate-600">${this.escapeHtml(quote.clientPhone || 'Sem telefone informado')}</p>
        </div>
        <div>
          <h5 class="font-bold text-slate-900 text-xs uppercase mb-1">Modalidade & Situação:</h5>
          <div class="flex items-center gap-2 mt-1">
            ${this.buildModalityBadge(quote.modality)}
            ${this.buildStatusBadge(quote.status, quote.deliveryStage)}
          </div>
        </div>
      </div>

      <!-- Foto da Embalagem no Comprovante -->
      ${quote.packageImage ? `
        <div class="py-3 border-b border-slate-200 flex items-center gap-4">
          <img src="${quote.packageImage}" alt="Foto da Carga" class="w-16 h-16 object-cover rounded-lg border border-slate-200 shadow-sm">
          <div>
            <span class="font-bold text-slate-900 uppercase text-[10px] block">Registro Fotográfico da Embalagem:</span>
            <p class="text-[11px] text-slate-500">Foto anexada pelo cliente para conferência de cubagem e integridade da embalagem.</p>
          </div>
        </div>
      ` : ''}

      <div class="grid grid-cols-2 gap-4 py-3 border-b border-slate-200">
        <div>
          <h5 class="font-bold text-slate-900 text-xs uppercase mb-1">Endereço de Origem (Coleta):</h5>
          <p class="text-slate-800">${this.escapeHtml(quote.origin)}</p>
        </div>
        <div>
          <h5 class="font-bold text-slate-900 text-xs uppercase mb-1">Endereço de Destino (Entrega):</h5>
          <p class="text-slate-800">${this.escapeHtml(quote.destination)}</p>
        </div>
      </div>

      <div class="py-3 border-b border-slate-200">
        <h5 class="font-bold text-slate-900 text-xs uppercase mb-2">Especificações da Carga:</h5>
        <div class="grid grid-cols-4 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
          <div>
            <span class="text-slate-400 text-[10px] block">Quantidade Volumes</span>
            <span class="font-bold text-slate-900 text-sm">${quote.packageCount}</span>
          </div>
          <div>
            <span class="text-slate-400 text-[10px] block">Peso Real</span>
            <span class="font-bold text-slate-900 text-sm">${quote.weight} kg</span>
          </div>
          <div>
            <span class="text-slate-400 text-[10px] block">Dimensões</span>
            <span class="font-bold text-slate-900 text-xs">${quote.dimensions.length}x${quote.dimensions.width}x${quote.dimensions.height} cm</span>
          </div>
          <div>
            <span class="text-slate-400 text-[10px] block">Cubagem Total</span>
            <span class="font-bold text-slate-900 text-xs">${(quote.dimensions.volumeCm3 / 1000).toFixed(1)} dm³</span>
          </div>
        </div>
        <p class="mt-2 text-slate-600"><strong>Conteúdo:</strong> ${this.escapeHtml(quote.description)}</p>
        ${quote.isFragile ? '<p class="text-red-700 font-semibold mt-1">⚠️ Mercadoria classificada como Frágil.</p>' : ''}
      </div>

      ${quote.proposal ? `
        <div class="py-4 border-b border-slate-200 bg-sky-50/50 p-4 rounded-xl border border-sky-200">
          <h5 class="font-bold text-sky-900 text-xs uppercase mb-2">Condições Comerciais Propostas:</h5>
          <div class="flex items-baseline justify-between mb-2">
            <span class="text-slate-600 font-semibold">Valor Total do Frete:</span>
            <span class="text-xl font-black text-slate-900">${this.formatCurrencyBRL(quote.proposal.price)}</span>
          </div>
          <div class="text-[11px] text-slate-600 space-y-1">
            <p><strong>Prazo Estimado de Entrega:</strong> ${this.escapeHtml(quote.proposal.estimatedTime)}</p>
            <p><strong>Observações:</strong> ${this.escapeHtml(quote.proposal.notes)}</p>
          </div>
        </div>
      ` : ''}

      <div class="pt-2">
        <h5 class="font-bold text-slate-900 text-xs uppercase mb-2">Linha do Tempo / Auditoria de Eventos:</h5>
        <div class="space-y-2">
          ${quote.history.map(h => `
            <div class="flex items-start gap-2 text-[11px] text-slate-600">
              <span class="w-2 h-2 rounded-full bg-slate-400 mt-1 flex-shrink-0"></span>
              <div>
                <span class="font-semibold text-slate-800">${h.action}</span> (${this.formatDate(h.date)}) por <em>${this.escapeHtml(h.user)}</em>
                <p class="text-slate-500 text-[10px]">${this.escapeHtml(h.note)}</p>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;

    document.getElementById('modal-quote-details').classList.remove('hidden');
    lucide.createIcons();
  }

  closeQuoteDetailsModal() {
    document.getElementById('modal-quote-details').classList.add('hidden');
  }

  // --- AUTENTICAÇÃO DE CLIENTE ---
  openAuthModal(tab = 'login') {
    document.getElementById('modal-auth').classList.remove('hidden');
    document.getElementById('auth-error-message').classList.add('hidden');
    this.switchAuthTab(tab);
    lucide.createIcons();
  }

  closeAuthModal() {
    document.getElementById('modal-auth').classList.add('hidden');
  }

  switchAuthTab(tab) {
    const loginBtn = document.getElementById('auth-tab-login-btn');
    const registerBtn = document.getElementById('auth-tab-register-btn');
    const loginForm = document.getElementById('form-login');
    const registerForm = document.getElementById('form-register');

    if (tab === 'login') {
      loginBtn.className = 'py-4 border-b-2 border-sky-600 text-sky-600 bg-sky-50/50';
      registerBtn.className = 'py-4 border-b-2 border-transparent text-slate-500 hover:text-slate-800';
      loginForm.classList.remove('hidden');
      registerForm.classList.add('hidden');
    } else {
      registerBtn.className = 'py-4 border-b-2 border-sky-600 text-sky-600 bg-sky-50/50';
      loginBtn.className = 'py-4 border-b-2 border-transparent text-slate-500 hover:text-slate-800';
      registerForm.classList.remove('hidden');
      loginForm.classList.add('hidden');
    }
  }

  handleLoginSubmit(e) {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const pass = document.getElementById('login-password').value;

    try {
      const user = window.logixStore.login(email, pass);
      this.closeAuthModal();
      this.showToast(`Bem-vindo de volta, ${user.name}!`, 'success');
      if (user.role === 'admin') {
        this.navigateTo('admin_dashboard');
      } else {
        this.navigateTo('client_dashboard');
      }
    } catch (err) {
      document.getElementById('auth-error-text').textContent = err.message;
      document.getElementById('auth-error-message').classList.remove('hidden');
    }
  }

  handleRegisterSubmit(e) {
    e.preventDefault();
    const data = {
      name: document.getElementById('reg-name').value,
      email: document.getElementById('reg-email').value,
      phone: document.getElementById('reg-phone').value,
      company: document.getElementById('reg-company').value,
      password: document.getElementById('reg-password').value
    };

    try {
      const user = window.logixStore.register(data);
      this.closeAuthModal();
      this.showToast(`Cadastro realizado com sucesso! Bem-vindo, ${user.name}`, 'success');
      this.navigateTo('client_dashboard');
    } catch (err) {
      document.getElementById('auth-error-text').textContent = err.message;
      document.getElementById('auth-error-message').classList.remove('hidden');
    }
  }

  logout() {
    window.logixStore.logout();
    this.navigateTo('landing');
    this.showToast('Você saiu da sua conta.', 'info');
  }

  // --- CONTROLE DE ABAS ---
  setClientTab(tab) {
    this.currentClientTab = tab;
    const btnProposals = document.getElementById('tab-client-proposals-btn');
    const btnHistory = document.getElementById('tab-client-history-btn');
    const contentProposals = document.getElementById('tab-client-proposals-content');
    const contentHistory = document.getElementById('tab-client-history-content');

    if (tab === 'proposals') {
      btnProposals.className = 'pb-3 text-sm font-bold border-b-2 border-sky-600 text-sky-600 flex items-center gap-2';
      btnHistory.className = 'pb-3 text-sm font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center gap-2';
      contentProposals.classList.remove('hidden');
      contentHistory.classList.add('hidden');
    } else {
      btnHistory.className = 'pb-3 text-sm font-bold border-b-2 border-sky-600 text-sky-600 flex items-center gap-2';
      btnProposals.className = 'pb-3 text-sm font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center gap-2';
      contentHistory.classList.remove('hidden');
      contentProposals.classList.add('hidden');
    }
    lucide.createIcons();
  }

  setAdminTab(tab) {
    this.currentAdminTab = tab;
    const btnPending = document.getElementById('tab-admin-pending-btn');
    const btnActive = document.getElementById('tab-admin-active-btn');
    const btnHistory = document.getElementById('tab-admin-history-btn');

    const contentPending = document.getElementById('tab-admin-pending-content');
    const contentActive = document.getElementById('tab-admin-active-content');
    const contentHistory = document.getElementById('tab-admin-history-content');

    const activeClasses = 'pb-3 text-sm font-bold border-b-2 border-sky-600 text-sky-600 flex items-center gap-2';
    const inactiveClasses = 'pb-3 text-sm font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center gap-2';

    btnPending.className = tab === 'pending' ? activeClasses : inactiveClasses;
    btnActive.className = tab === 'active' ? activeClasses : inactiveClasses;
    btnHistory.className = tab === 'history' ? activeClasses : inactiveClasses;

    contentPending.classList.toggle('hidden', tab !== 'pending');
    contentActive.classList.toggle('hidden', tab !== 'active');
    contentHistory.classList.toggle('hidden', tab !== 'history');

    lucide.createIcons();
  }

  // --- EXPORTAÇÃO CSV ---
  exportHistoryCSV() {
    const quotes = window.logixStore.quotes;
    let csv = 'Codigo,Data,Cliente,Email,Telefone,Modalidade,Origem,Destino,Volumes,Peso_kg,Status,Etapa_Entrega,Preco_BRL,Prazo_Entrega\n';

    quotes.forEach(q => {
      const price = q.proposal ? q.proposal.price : '';
      const eta = q.proposal ? `"${q.proposal.estimatedTime.replace(/"/g, '""')}"` : '';
      const mod = q.modality === 'aereo' ? 'Aereo' : 'Rodoviario';
      csv += `${q.id},"${q.createdAt}","${q.clientName}","${q.clientEmail}","${q.clientPhone}","${mod}","${q.origin}","${q.destination}",${q.packageCount},${q.weight},"${q.status}","${q.deliveryStage || 'N/A'}",${price},${eta}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `top10cargas_historico_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    this.showToast('Relatório baixado em CSV com sucesso!', 'info');
  }

  // --- AUXILIARES E FORMATAÇÃO ---
  formatCurrencyBRL(value) {
    if (typeof value !== 'number') value = parseFloat(value) || 0;
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  }

  buildModalityBadge(modality) {
    if (modality === 'aereo') {
      return '<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200"><i data-lucide="plane" class="w-3 h-3 text-sky-600"></i> Aéreo</span>';
    }
    return '<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200"><i data-lucide="truck" class="w-3 h-3 text-emerald-600"></i> Rodoviário</span>';
  }

  buildStatusBadge(status, deliveryStage = null) {
    if (status === 'ACEPTADA') {
      if (deliveryStage === 'em_transito') {
        return '<span class="badge-status badge-propuesta"><i data-lucide="truck" class="w-3 h-3 animate-pulse"></i> A Caminho / Em Trânsito</span>';
      } else if (deliveryStage === 'saiu_entrega') {
        return '<span class="badge-status bg-purple-100 text-purple-800 border border-purple-200"><i data-lucide="map-pin" class="w-3 h-3 animate-pulse"></i> Saiu para Entrega</span>';
      } else if (deliveryStage === 'entregue') {
        return '<span class="badge-status badge-completado"><i data-lucide="check-circle-2" class="w-3 h-3"></i> Entregue</span>';
      }
      return '<span class="badge-status badge-aceptada"><i data-lucide="clock" class="w-3 h-3"></i> Aguardando Coleta</span>';
    }

    switch (status) {
      case 'PENDIENTE_ANALISIS':
        return '<span class="badge-status badge-pendiente"><i data-lucide="clock" class="w-3 h-3"></i> Sujeita a Análise</span>';
      case 'PROPUESTA_ENVIADA':
        return '<span class="badge-status badge-propuesta"><i data-lucide="send" class="w-3 h-3"></i> Proposta Enviada</span>';
      case 'DENEGADA':
        return '<span class="badge-status badge-denegada"><i data-lucide="x-circle" class="w-3 h-3"></i> Recusada</span>';
      case 'REANALISIS_SOLICITADO':
        return '<span class="badge-status badge-reanalisis"><i data-lucide="refresh-cw" class="w-3 h-3"></i> Reanálise Solicitada</span>';
      case 'COMPLETADO':
        return '<span class="badge-status badge-completado"><i data-lucide="award" class="w-3 h-3"></i> Entregue com Sucesso</span>';
      default:
        return `<span class="badge-status badge-completado">${status}</span>`;
    }
  }

  formatDate(isoString) {
    if (!isoString) return '';
    const d = new Date(isoString);
    return d.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  showToast(message, type = 'info') {
    const existing = document.getElementById('app-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.id = 'app-toast';
    
    let bg = 'bg-slate-900 text-white';
    let icon = 'info';
    if (type === 'success') { bg = 'bg-emerald-600 text-white'; icon = 'check-circle'; }
    if (type === 'warning') { bg = 'bg-amber-600 text-white'; icon = 'alert-triangle'; }
    if (type === 'error') { bg = 'bg-red-600 text-white'; icon = 'alert-circle'; }

    toast.className = `fixed bottom-6 right-6 z-50 ${bg} px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2.5 text-xs font-semibold animate-fade-in border border-white/10`;
    toast.innerHTML = `<i data-lucide="${icon}" class="w-4 h-4"></i> <span>${this.escapeHtml(message)}</span>`;
    document.body.appendChild(toast);
    lucide.createIcons();

    setTimeout(() => {
      toast.style.transition = 'opacity 0.4s ease';
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 400);
    }, 3500);
  }
}

window.app = new App();
